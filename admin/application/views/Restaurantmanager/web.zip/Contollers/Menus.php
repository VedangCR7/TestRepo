<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Menus extends MY_Controller {
	
	public function __construct() {
		parent::__construct();
		$this->load->model('user_model');	
		$this->load->model('main_menu_model');	
		$this->load->model('menu_group_model');	
		$this->load->model('recipes_model');	
		$this->load->model('ingredient_items_model');	
	}
	
	public function index($main_menu_id,$restid,$tableid="") {

		$m=$this->main_menu_model;
		$m->id=$main_menu_id;
		$main_menu_details=$m->get();
		$user=$this->user_model->get_active_user($restid);
		$data=array(
			'restid'=>$restid,
			'user'=>$user,
			'main_menu_id'=>$main_menu_id,
			'menu_groups'=>$this->menu_group_model->get_user_menugroups($restid,$main_menu_id),
			'main_menu'=>$main_menu_details,
			'todays_special'=>$this->recipes_model->list_todays_special_userwise($restid,$main_menu_id),
			'tableid'=>$tableid
		);
		$this->load->view('web/menu_list',$data);
	}

	public function newtest($tableid="") {
		$main_menu_id=1;
		$restid=112;
		$m=$this->main_menu_model;
		$m->id=$main_menu_id;
		$main_menu_details=$m->get();
		$user=$this->user_model->get_active_user($restid);
		$data=array(
			'restid'=>$restid,
			'user'=>$user,
			'main_menu_id'=>$main_menu_id,
			'menu_groups'=>$this->menu_group_model->get_user_menugroups($restid,$main_menu_id),
			'main_menu'=>$main_menu_details,
			'todays_special'=>$this->recipes_model->list_todays_special_userwise($restid,$main_menu_id),
			'tableid'=>$tableid
		);
		$this->load->view('web/test',$data);
	}

	public function get_recipe_ingredients(){
		$ingredients=$this->menu_group_model->get_ingredients($_POST['recipe_id']);
		$this->json_output(array('status'=>true,'ingredients'=>$ingredients));
	}

	public function view($group_id,$recipe_id,$restid) {

		$m=$this->menu_group_model;
		$m->id=$group_id;
		$group_details=$m->get();
		$user=$this->user_model->get_active_user($restid);

		$this->recipes_model->update_recipe_visit_count($recipe_id,$group_id,$restid);
		$data=array(
			'restid'=>$restid,
			'recipe_id'=>$recipe_id,
			'user'=>$user,
			'recipe'=>$this->recipes_model->get_recipe_withoutingredients($recipe_id),
			'group_details'=>$group_details,
			'main_menu_id'=>$group_details['main_menu_id']
		);
		
		$this->load->view('web/menu_details',$data);
	}

	public function list_recipe_ingredients(){
		$ingredients=$this->ingredient_items_model->get_ingredients($_POST['recipe_id']);
		$this->json_output(array('status'=>true,'ingredients'=>$ingredients));
	}


}
?>