<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Qrcode extends MY_Controller {
	
	public function __construct() {
		parent::__construct();
		$this->load->model('user_model');	
		$this->load->model('main_menu_model');	
	}
	
	public function index($restid,$tableid="") {

		/*$m=$this->main_menu_model;
		$main_menu_details=$m->list_all();*/
		if (base64_encode(base64_decode($restid, true)) === $restid){
			$restid = base64_decode($restid);
		}
		if($tableid!=""){
			if (base64_encode(base64_decode($tableid, true)) === $tableid)
				$tableid=base64_decode($tableid);
			else
				$tableid="";
		}

		$user=$this->user_model->get_active_user($restid);
		if($user!="notactivated")
			$this->user_model->update_restaurant_visit_count($restid);
		$data=array(
			'restid'=>$restid,
			'user'=>$user,
			'menu_groups'=>$this->user_model->get_main_menugroup_byuser($restid)
		);
		if($tableid!=""){
			$data['table']=$this->user_model->get_table_details($tableid);
		}else{
			$data['table']=array();
		}
		$data['tableid']=$tableid;
		$this->load->view('web/web_hotel',$data);
	}


}
?>