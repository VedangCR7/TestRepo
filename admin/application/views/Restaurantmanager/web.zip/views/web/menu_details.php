<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta content="Foodnai" name="description">
    <meta content="foodnai.com" name="author">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?=base_url();?>assets/images/brand/FoodNAI_favicon.png" />

    <!-- Title -->
    <title>FoodNAI - food allergen nutrition information</title>

    <!-- Css Library -->

    <link rel="stylesheet" href="<?=base_url();?>assets/web/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?=base_url();?>assets/web/css/animate.css">
     <link href="<?=base_url();?>assets/web/css/feather.css" rel="stylesheet" type="text/css">

   <!-- Style css -->
    <link rel="stylesheet" href="<?=base_url();?>assets/web/css/style.css?v=9">
</head>

<body data-spy="scroll" data-target=".maks" data-offset="90">
        <?php
            if($recipe['recipe_image']=="" || $recipe['recipe_image']=="assets/images/users/menu.png")
                $recipe_image=base_url()."assets/images/users/menu.png";
            else
                 $recipe_image=$recipe['recipe_image'];
        ?>
    <div class="menu-promo"  style="background-image:url('<?=$recipe_image;?>');background-repeat: no-repeat;background-size: cover;background-position: center;">
       <!--  <a href="<?=base_url()?>menus/<?=$group_details['main_menu_id'];?>/<?=$restid;?>" class="custom-btn">Back</a> -->
        <a href='<?=base_url()?>menus/<?=$group_details['main_menu_id'];?>/<?=$restid;?>' id="backLink" class="bckToMainPage custom-btn" style="color: #fff;">
            <i class=" feather-arrow-left"></i> 
        </a>
    </div>
    <!-- Single menu Section Start -->
    <section class="single-menu section-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="menu-inner">
                        <div class="menu-head mb-3">
                            <h1 class="menu-title"><?=$recipe['name'];?>
                               
                                <div class="footer-choose float-right">
                                    <?php 
                                        if($recipe['recipe_type']=="veg") {
                                    ?>
                                    <a href="#"><img src="<?=base_url();?>assets/web/images/vg.png" alt=""></a>

                                    <?php
                                        } 
                                        else if($recipe['recipe_type']=="nonveg"){
                                    ?>
                                    <a href="#"><img src="<?=base_url();?>assets/web/images/nv.png" alt=""></a>
                                    <?php

                                        }else{
                                    ?>
                                     <a href="#"><img src="<?=base_url();?>assets/web/images/vegnoveg.png" alt=""></a>
                                    <?php
                                        }
                                    ?>
                                </div>
                            </h1>
                            <?php
                             if($main_menu_id==2){
                                    $multi_prices=array();
                                    if($recipe['price'] !='' && $recipe['quantity'] != ''){
                                        $multi_prices[$recipe['quantity']]= $recipe['price']; 
                                    }
                                    
                                    if($recipe['price1'] !='' && $recipe['quantity1'] !=''){
                                        $multi_prices[$recipe['quantity1']] = $recipe['price1'];
                                    }
                                        
                                    if($recipe['price2'] !='' && $recipe['quantity2'] !=''){
                                        $multi_prices[$recipe['quantity2']] = $recipe['price2'];
                                    }
                                        
                                    if($recipe['price3'] !='' && $recipe['quantity3'] !=''){
                                        $multi_prices[$recipe['quantity3']] = $recipe['price3'];
                                    }
                                       
                                    if($resto_id == 103){
                                        $currency = 'MZN';
                                    }
                                    else{ 
                                        $currency = '&#8377;'; 
                                    }
                                    $bar_prices="";
                                    foreach($multi_prices as $k => $v) { 
                                        if($bar_prices=="")
                                            $bar_prices = "<b>$k :</b> $currency $v/-"; 
                                        else
                                            $bar_prices = "<b>$k :</b> $currency $v/-"; 
                                        ?>
                                    <span class="price-meta">   
                                          <?=$bar_prices;?>
                                    </span><br>
                                <?php
                                    }
                                } else{
                                    if($recipe['price']=='Recipe Price' || $recipe['price']=='' || $recipe['price']=="MRP" || $recipe['price']=="dv.kjndvkjnd"){
                                        if($restid == 103){ $price1 = 'MZN 0.00/-'; }
                                        else{ $price1='&#8377; 0.00/-'; }
                                    }else{
                                        if($restid == 103){ $price1='MZN '.$recipe['price'].'/-'; }
                                        else { $price1='&#8377; '.$recipe['price'].'/-'; }
                                    }
                                   
                                ?>
                                    <span class="price-meta">
                                        <?php  echo $price1; ?>
                                    </span>
                                <?php
                                }
                                ?>
                        </div>
                        <div class="menu-txt">
                            <ul class="menu-ingredients">
                               
                            </ul>
                            <?php
                            if($recipe['description']!=""){
                            ?>
                                <p><?=$recipe['description'];?></p>
                            <?php
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Single menu Section End -->

    <footer class="footer section-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="footer-inner text-center">
                        <div class="f-logo text-center">
                            <?php
                            if($user['profile_photo']=="assets/images/users/user.png" || $user['profile_photo']==""){
                              ?>
                                  <img src="<?php echo base_url().$user['profile_photo']; ?>" alt="">
                              <?php
                                }else{
                              ?>
                                 <img src="<?php echo $user['profile_photo']; ?>" alt="">
                              <?php
                                }
                                ?>
                           
                        </div>
                        <div class="footer-social">
                            <h3>Share On</h3>
                            <ul>
                                <li><a href="#"><i class="feather-facebook"></i></a></li>
                                <li><a href="#"><i class="feather-twitter"></i></a></li>
                                <li><a href="#"><i class="feather-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--
Javascript
========================================================-->
    <script src="<?=base_url();?>assets/web/js/jquery-3.5.1.min.js"></script>
    <script src="<?=base_url();?>assets/web/js/bootstrap.min.js"></script>
    <script type="text/javascript">
        function capitalize_Words(str)
        {
         return str.replace(/\w\S*/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
        }
       $(document).ready(function() {
            $.ajax({
                url: "<?=base_url();?>menus/list_recipe_ingredients",
                type:'POST',
                dataType: 'json',
                data: {recipe_id :'<?=$recipe_id;?>'},
                success: function(result){
                    if (result.status) { 
                        if(result.ingredients!=null){
                            var ingredients=result.ingredients;
                            var html='';
                            for(i in ingredients){
                              html+='<li><span>'+capitalize_Words(ingredients[i].declaration_name)+'</span> - '+capitalize_Words(ingredients[i].long_desc)+'</li>';
                            }
                            $('.menu-ingredients').html(html);
                        }
                    }
                }
            });
        });

    </script>
</body>

</html>