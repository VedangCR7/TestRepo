<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="Foodnai" name="description">
        <meta content="foodnai.com" name="author">
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="<?=base_url();?>assets/images/brand/FoodNAI_favicon.png" />

        <!-- Title -->
        <title>FoodNAI - food allergen nutrition information</title>
        <link rel="stylesheet" href="<?=base_url();?>assets/web/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?=base_url();?>assets/web/css/owl.carousel.min.css">
        <link rel="stylesheet" href="<?=base_url();?>assets/web/css/animate.css">
         <link href="<?=base_url();?>assets/web/css/feather.css" rel="stylesheet" type="text/css">
        <!-- Style css -->
        <link rel="stylesheet" href="<?=base_url();?>assets/web/css/style.css?v=3">
   </head>
   <body data-spy="scroll" data-target=".maks" data-offset="90">
         <div class="spinner1"><p class="loaderTxt"><b><?php echo $user['business_name']; ?></b><div class="spinner"></div></p></div>
        <div class="menu-navigation">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 mb-2">
                        <div class="text-white">
                           <div class="title d-flex align-items-center">
                              <a href='<?=base_url();?>qrcode/<?=base64_encode($restid);?>/<?=base64_encode($tableid);?>' id="backLink" class="bckToMainPage">
                                <i class=" feather-arrow-left"></i> 
                              </a>
                              <h4 class="resto-name ml-2"><center><b><?=$user['business_name']; ?></b></center></h4>
                              <!--<img class="logo"src="<?php echo $r_image; ?>">-->
                           </div>
                        </div>
                        <div class="input-group mt-3 rounded shadow-sm overflow-hidden" style="margin-top: 0.5rem!important;">
                           <div class="input-group-prepend">
                              <button class="border-0 btn btn-outline-secondary text-dark bg-white btn-block"><i class="feather-search"></i></button>
                           </div>
                           <input type="text" class="shadow-none border-0 form-control" id="input-search" placeholder="Search for <?=$main_menu['name'];?>s" aria-label="" aria-describedby="basic-addon1">
                        </div>
                        <div class='searchBoxRes'>
                            <div id='basicsAccordion' style='display:none;'>
                                
                            </div>
                        </div>
                     </div> 
                    <div class="col-lg-12 ">
                        <div class="nav-carousel owl-carousel">
                           <!--  <?php
                                if(count($todays_special)>0){
                            ?>
                            <a href="#todays-special" class="item a-group-item">
                                <img src="<?=base_url();?>assets/images/users/5.jpg" alt="menu">
                                <span>Today's Special</span>
                            </a>
                            <?php
                                }
                            ?> -->
                            <?php
                            foreach ($menu_groups as $group) {
                                if(count($group['recipes'])>0){
                            ?>
                                <a href="#group-<?=$group['id'];?>" class="item a-group-item">
                                    <?php
                                        if($group['image_path']!=""){
                                    ?>
                                    <img src="<?=$group['image_path'];?>" alt="menu">
                                    <?php
                                        }
                                        else{
                                    ?>
                                    <img src="<?=base_url();?>assets/images/users/menugroup.png" alt="menu">
                                    <?php
                                        }
                                    ?>
                                    <p class="p-group-name"> <?=$group['title'];?></p>
                                </a>
                            <?php
                                }
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Menu Carousel Section End -->
        <div class="space"></div>
        <!-- Menu Section Start -->
        <div class="menu-section section-search-padding" id="search-list-menu" style="display: none;">
            <div class="container">
                <div class="row div-search-list">
                    
                </div>
            </div>
        </div>
        <?php

            if(count($todays_special)>0){
        ?>
        <div class="menu-section menu-section-recipes section-padding menu-details-div" id="todays-special">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-header">
                            <h2 class="section-title">Today's Special</h2>
                            <!-- <h4>2 Courses & 3 Courses</h4> -->
                        </div>
                    </div>
                </div>
                <div class="row">
                    <?php
                     foreach ($todays_special as $recipe) {
                    ?>
                    <div class="col-lg-6 col-sm-12 col6-food-menu">
                        <div class="food-menu">
                            <div class="row">
                                <div class="col-3 pr-0">
                                    <div class="col-12 p-0 justify-content-center">
                                         <?php
                                        if($recipe['recipe_image']=="" || $recipe['recipe_image']=="assets/images/users/menu.png")
                                            $recipe_image=base_url()."assets/images/users/menu.png";
                                        else
                                             $recipe_image=$recipe['recipe_image'];
                                        ?>
                                        <div class="menu-img <?php if($recipe['recipe_type']=="veg") echo 'veg-recipe'; else if($recipe['recipe_type']=="nonveg") echo 'nonveg-recipe';?>" style="background-image:url('<?=$recipe_image;?>');background-repeat: no-repeat;background-size: cover;background-position: center;">
                                            <!-- <img src="<?=$recipe['recipe_image']?>" alt=""> -->
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                    <div class="col-12 p-0">
                                        <p class="price-meta">
                                            <?php
                                                if($recipe['price']=='Recipe Price' || $recipe['price']=='' || $recipe['price']=="MRP" || $recipe['price']=="dv.kjndvkjnd"){
                                                    if($restid == 103){ $price1 = 'MZN 0.00/-'; }
                                                    else{ $price1='&#8377; 0.00/-'; }
                                                }else{
                                                    if($restid == 103){ $price1='MZN '.$recipe['price'].'/-'; }
                                                    else { $price1='&#8377; '.$recipe['price'].'/-'; }
                                                }
                                                echo $price1;
                                            ?>
                                        </p>
                                        
                                    </div>
                                </div>
                                <div class="col-9 pr-0">
                                    <div class="menu-txt">
                                        <h3>
                                            <a href="<?=base_url();?>menus/view/<?=$group['id'];?>/<?=$recipe['id'];?>/<?=$restid;?>"><?php echo ucwords(strtolower($recipe['name'])); ?></a>
                                        </h3>
                                         
                                        <ul class="menu-ingredients" recipe-id="<?=$recipe['id'];?>">
                                            <li class="li-ingredients"><?=$recipe['description'];?></li>
                                                <?php
                                                $best_time_to_eat= $recipe['best_time_to_eat'];
                                                if($best_time_to_eat == 'none'){
                                                    $best_time_to_eat = '';
                                                }
                                                
                                                $besttime_arr1 = explode(",",$best_time_to_eat);
                                                if(array_search('all', $besttime_arr1) == 'TRUE')
                                                {
                                                    $pos1 = array_search('all', $besttime_arr1);
                                                    unset($besttime_arr1[$pos1]);
                                                }
                                                
                                                $best_time_to_eat = implode(", ",$besttime_arr1); 
                                                if($best_time_to_eat != ''){ 
                                                    ?>
                                                    <li>   

                                                    <span class="badge badge-danger">Best Time To Eat : </span> 
                                                      <small><?php echo ucwords($best_time_to_eat); ?></small>
                                                  </li>
                                               <?php }
                                               else{
                                                ?>
                                                <li style="height: 33px;">
                                                </li> 
                                                <?php
                                               }
                                                ?>
                                            <li class="view-recipe">
                                                <span class="badge badge-success"><a href="<?=base_url();?>menus/view/<?=$group['id'];?>/<?=$recipe['id'];?>/<?=$restid;?>">View</a></span>
                                            </li>
                                        </ul>
                                         
                                    </div> 
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                        }
                    ?>
                </div>
            </div>
        </div>
        <?php
        }
        $count=1;
        foreach ($menu_groups as $group) {
            if(count($group['recipes'])>0){
                if(count($todays_special)==0 && $count==1) {
                    $pad_class="section-padding";
                    $count++;
                }
                else
                    $pad_class="";
        ?>
        <div class="menu-section menu-section-recipes <?=$pad_class;?> menu-details-div" id="group-<?=$group['id'];?>">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-header">
                            <h2 class="section-title"> <?=$group['title'];?></h2>
                            <!-- <h4>2 Courses & 3 Courses</h4> -->
                        </div>
                    </div>
                </div>
                <div class="row">
                    <?php
                     foreach ($group['recipes'] as $recipe) {
                    ?>
                    <div class="col-lg-6 col-sm-12 col6-food-menu">
                        <div class="food-menu">
                            <div class="row">
                                <div class="col-3 pr-0">
                                    <div class="col-12 p-0 justify-content-center">
                                        <?php
                                        if($recipe['recipe_image']=="" || $recipe['recipe_image']=="assets/images/users/menu.png")
                                            $recipe_image=base_url()."assets/images/users/menu.png";
                                        else
                                             $recipe_image=$recipe['recipe_image'];
                                        ?>
                                        <div class="menu-img <?php if($recipe['recipe_type']=="veg") echo 'veg-recipe'; else if($recipe['recipe_type']=="nonveg") echo 'nonveg-recipe';?>" style="background-image:url('<?=$recipe_image;?>');background-repeat: no-repeat;background-size: cover;background-position: center;">
                                            <!-- <img src="<?=$recipe['recipe_image']?>" alt=""> -->
                                        </div>
                                    </div>
                                    <?php
                                    if($main_menu_id==1){
                                    ?>
                                    <div class="clearfix"></div>
                                    <div class="col-12 p-0">
                                        <p class="price-meta mb-0">
                                            <?php
                                                if($recipe['price']=='Recipe Price' || $recipe['price']==''){
                                                    if($restid == 103){ $price1 = 'MZN 0.00/-'; }
                                                    else{ $price1='&#8377; 0.00/-'; }
                                                }else{
                                                    if($restid == 103){ $price1='MZN '.$recipe['price'].'/-'; }
                                                    else { $price1='&#8377; '.$recipe['price'].'/-'; }
                                                }
                                                echo $price1;
                                            ?>
                                        </p>
                                    </div>
                                    <?php
                                        }
                                    ?>
                                </div>
                                <div class="col-9 pr-0">
                                    <div class="menu-txt">
                                        <h3>
                                            <a href="<?=base_url();?>menus/view/<?=$group['id'];?>/<?=$recipe['id'];?>/<?=$restid;?>" class="food-recipe-name"><?php echo ucwords(strtolower($recipe['name'])); ?></a>
                                        </h3>
                                         
                                        <ul class="menu-ingredients" recipe-id="<?=$recipe['id'];?>">
                                            <li class="li-ingredients"><?=$recipe['description'];?></li>
                                            <?php
                                            if($main_menu_id==2){
                                                $multi_prices=array();
                                                if($recipe['price'] !='' && $recipe['quantity'] != ''){
                                                    $multi_prices[$recipe['quantity']]= $recipe['price']; 
                                                }
                                                
                                                if($recipe['price1'] !='' && $recipe['quantity1'] !=''){
                                                    $multi_prices[$recipe['quantity1']] = $recipe['price1'];
                                                }
                                                    
                                                if($recipe['price2'] !='' && $recipe['quantity2'] !=''){
                                                    $multi_prices[$recipe['quantity2']] = $recipe['price2'];
                                                }
                                                    
                                                if($recipe['price3'] !='' && $recipe['quantity3'] !=''){
                                                    $multi_prices[$recipe['quantity3']] = $recipe['price3'];
                                                }
                                                   
                                                if($resto_id == 103){
                                                    $currency = 'MZN';
                                                }
                                                else{ 
                                                    $currency = '&#8377;'; 
                                                }
                                                $bar_prices="";
                                                foreach($multi_prices as $k => $v) { 
                                                    if($bar_prices=="")
                                                        $bar_prices = "<b>$k :</b> $currency $v/-"; 
                                                    else
                                                        $bar_prices = "<b>$k :</b> $currency $v/-"; 
                                                    ?>
                                                <li class="bar-price">   
                                                      <?=$bar_prices;?>
                                                </li>
                                                <?php
                                                } 
                                            ?>
                                            <?php
                                            }else{
                                            ?>
                                             <?php
                                                $best_time_to_eat= $recipe['best_time_to_eat'];
                                                if($best_time_to_eat == 'none'){
                                                    $best_time_to_eat = '';
                                                }
                                                
                                                $besttime_arr1 = explode(",",$best_time_to_eat);
                                                if(array_search('all', $besttime_arr1) == 'TRUE')
                                                {
                                                    $pos1 = array_search('all', $besttime_arr1);
                                                    unset($besttime_arr1[$pos1]);
                                                }
                                                
                                                $best_time_to_eat = implode(", ",$besttime_arr1); 
                                                if($best_time_to_eat != ''){ 
                                                    ?>
                                                    <li>   

                                                    <span class="badge badge-danger">Best Time To Eat : </span> 
                                                      <small><?php echo ucwords($best_time_to_eat); ?></small>
                                                  </li>
                                               <?php }
                                               else{
                                                ?>
                                                <li style="height: 33px;">
                                                </li> 
                                                <?php
                                               }
                                            }
                                                ?>
                                            <li class="view-recipe">
                                                <span class="badge badge-success mb-0"><a href="<?=base_url();?>menus/view/<?=$group['id'];?>/<?=$recipe['id'];?>/<?=$restid;?>">View</a></span>
                                            </li>
                                        </ul>
                                         
                                    </div> 
                                </div>
                            </div>
                           
                        </div>
                    </div>
                    <?php
                        }
                    ?>
                </div>
            </div>
        </div>
        <?php
           }
          
        }
        ?>
        <script src="<?=base_url();?>assets/web/js/jquery-3.5.1.min.js"></script>
        <script src="<?=base_url();?>assets/web/js/popper.min.js"></script>
        <script src="<?=base_url();?>assets/web/js/bootstrap.min.js"></script>
        <script src="<?=base_url();?>assets/web/js/owl.carousel.min.js"></script>
        <script src="<?=base_url();?>assets/web/js/jquery.easing.1.3.js"></script>
        <script src="<?=base_url();?>assets/web/js/custom.js"></script>
        <script>
            $(".owl-carousel").owlCarousel({
                  autoPlay: 1000,
                  loop:true,
                  smartSpeed: 650,
                  items : 3, // THIS IS IMPORTANT
                  responsive : {
                        480 : { items : 3  }
                    },
            });
            $('#input-search').on('keyup',function(){
                var search=$(this).val();
                if(search==""){
                    $('.div-search-list').html('');
                    $('#search-list-menu').hide();
                    $('.menu-section-recipes').show();
                }else{
                    var self=$(this);
                    $('.div-search-list').html('');
                    $('.menu-section-recipes').hide();
                    $('.food-recipe-name').each(function(e){
                        var name=$(this).html();
                        if(name){
                            if (name.toUpperCase().indexOf(search.toUpperCase())>-1) {
                                var closest_div=$(this).closest('.col6-food-menu');
                                $('.div-search-list').append(closest_div.clone()).html();
                            }
                        }
                    });
                    $('#search-list-menu').show();
                }
                $('html, body').animate({
                    scrollTop: $('#search-list-menu').offset().top 
                }, 'fast');
            });
            $('.a-group-item').on('click',function(){
                $('.div-search-list').html('');
                $('#search-list-menu').hide();
                $('#input-search').val('');
                $('.menu-section-recipes').show();
                var href=$(this).attr('href');
                     $('html, body').animate({
                        scrollTop: $(''+href).offset().top -210 
                    }, 'fast');
                setTimeout(function () {
                }, 100);
            });
            $(window).on('load', function(){ 
                $(".spinner1").fadeOut("fast");
                $('.menu-ingredients').each(function(e){
                    var self=$(this);
                    $.ajax({
                        url: "<?=base_url();?>menus/get_recipe_ingredients",
                        type:'POST',
                        dataType: 'json',
                        data: {recipe_id :$(this).attr('recipe-id')},
                        success: function(result){
                            if (result.status) { 
                                if(result.ingredients=="")
                                   $('.view-recipe').hide();
                                if(result.ingredients!=null){
									var newstr = result.ingredients;
									
									newstr = newstr.split(",");
									for (var i = 0, x = newstr.length; i < x; i++) {
										newstr[i] = newstr[i][0].toUpperCase() + newstr[i].substr(1);
									}
									var nwstr = newstr.join(",");
									
									nwstr = nwstr.split(" ");
									for (var i = 0, x = nwstr.length; i < x; i++) {
										nwstr[i] = nwstr[i][0].toUpperCase() + nwstr[i].substr(1);
									}
									
                                    self.find('li:first-child').html(nwstr.join(" "));
                                }
                            }
                        }
                    });
                    setTimeout(function () {
                    }, 1000);
                });
            });
           /* var link='<?php if(isset($_GET['link'])) echo $_GET['link']; else echo '';?>';
            if(link!=""){
                var this_w=$('[href="#'+link+'"]');
                this_w.trigger('click');
            }*/
        </script>
   </body>
</html>